﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lines98UI;

internal struct State
{
    public bool BallPicked;
    public (int i, int j) Cell;

}
