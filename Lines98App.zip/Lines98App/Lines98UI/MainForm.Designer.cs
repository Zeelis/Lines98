﻿namespace Lines98UI
{
    partial class MainForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.Ball1 = new System.Windows.Forms.Label();
            this.Ball2 = new System.Windows.Forms.Label();
            this.Ball3 = new System.Windows.Forms.Label();
            this.TableGrid = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.Score = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.TableGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // Ball1
            // 
            this.Ball1.Font = new System.Drawing.Font("Segoe UI", 28.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Ball1.Location = new System.Drawing.Point(12, 22);
            this.Ball1.Name = "Ball1";
            this.Ball1.Size = new System.Drawing.Size(150, 80);
            this.Ball1.TabIndex = 3;
            this.Ball1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Ball1.Click += new System.EventHandler(this.NextHand_Click);
            // 
            // Ball2
            // 
            this.Ball2.Font = new System.Drawing.Font("Segoe UI", 28.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Ball2.Location = new System.Drawing.Point(169, 22);
            this.Ball2.Name = "Ball2";
            this.Ball2.Size = new System.Drawing.Size(150, 80);
            this.Ball2.TabIndex = 3;
            this.Ball2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Ball2.Click += new System.EventHandler(this.NextHand_Click);
            // 
            // Ball3
            // 
            this.Ball3.Font = new System.Drawing.Font("Segoe UI", 28.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Ball3.Location = new System.Drawing.Point(325, 22);
            this.Ball3.Name = "Ball3";
            this.Ball3.Size = new System.Drawing.Size(150, 80);
            this.Ball3.TabIndex = 3;
            this.Ball3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Ball3.Click += new System.EventHandler(this.NextHand_Click);
            // 
            // TableGrid
            // 
            this.TableGrid.AllowUserToAddRows = false;
            this.TableGrid.AllowUserToDeleteRows = false;
            this.TableGrid.AllowUserToResizeColumns = false;
            this.TableGrid.AllowUserToResizeRows = false;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.WhiteSmoke;
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.WhiteSmoke;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.WhiteSmoke;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.WhiteSmoke;
            this.TableGrid.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle3;
            this.TableGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.TableGrid.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.TableGrid.CausesValidation = false;
            this.TableGrid.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
            this.TableGrid.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.TableGrid.ColumnHeadersHeight = 29;
            this.TableGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.TableGrid.ColumnHeadersVisible = false;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.WhiteSmoke;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.WhiteSmoke;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.WhiteSmoke;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.WhiteSmoke;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.TableGrid.DefaultCellStyle = dataGridViewCellStyle4;
            this.TableGrid.EnableHeadersVisualStyles = false;
            this.TableGrid.Location = new System.Drawing.Point(12, 124);
            this.TableGrid.MultiSelect = false;
            this.TableGrid.Name = "TableGrid";
            this.TableGrid.ReadOnly = true;
            this.TableGrid.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.TableGrid.RowHeadersVisible = false;
            this.TableGrid.RowHeadersWidth = 51;
            this.TableGrid.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.TableGrid.RowTemplate.Height = 29;
            this.TableGrid.RowTemplate.ReadOnly = true;
            this.TableGrid.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.TableGrid.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.TableGrid.ShowCellErrors = false;
            this.TableGrid.ShowCellToolTips = false;
            this.TableGrid.ShowEditingIcon = false;
            this.TableGrid.ShowRowErrors = false;
            this.TableGrid.Size = new System.Drawing.Size(463, 463);
            this.TableGrid.TabIndex = 4;
            this.TableGrid.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Table_CellEnter);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Segoe UI", 28.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(12, 610);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(277, 60);
            this.label1.TabIndex = 3;
            this.label1.Text = "Your Score:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label1.Click += new System.EventHandler(this.NextHand_Click);
            // 
            // Score
            // 
            this.Score.Font = new System.Drawing.Font("Segoe UI", 28.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Score.Location = new System.Drawing.Point(295, 610);
            this.Score.Name = "Score";
            this.Score.Size = new System.Drawing.Size(163, 60);
            this.Score.TabIndex = 3;
            this.Score.Text = "0";
            this.Score.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Score.Click += new System.EventHandler(this.NextHand_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(489, 699);
            this.Controls.Add(this.TableGrid);
            this.Controls.Add(this.Ball3);
            this.Controls.Add(this.Ball2);
            this.Controls.Add(this.Score);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Ball1);
            this.Name = "MainForm";
            this.Text = "Lines 98";
            this.Load += new System.EventHandler(this.MainForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.TableGrid)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private Label Ball1;
        private Label Ball2;
        private Label Ball3;
        private DataGridView TableGrid;
        private Label label1;
        private Label Score;
    }
}