﻿using Lines98Logic;

namespace Lines98UI;

public partial class MainForm : Form
{
    private Game Game { get; }
    private State State;
    public MainForm()
    {
        InitializeComponent();

        int tableSize = 9;

        Game = new Game(tableSize, 3);
        for (int _ = 0; _ < tableSize; _++)
            TableGrid.Columns.Add(null, null);
        for (int i = 0; i < tableSize; i++)
            TableGrid.Rows.Add(new DataGridViewRow { Height = TableGrid.Height / tableSize - 1 });

        for (int i = 0; i < TableGrid.Rows.Count; i++)
            for (int j = 0; j < TableGrid.Columns.Count; j++)
                TableGrid.Rows[i].Cells[j].Value = "⚫";

        Ball1.Text = Ball2.Text = Ball3.Text = "⚫";
    }

    private void MainForm_Load(object sender, EventArgs e)
    {
        Game.GenerateNextHand();
        Game.ApplyNextHand();
        Game.GenerateNextHand();

        RefreshNextHand();
        RefreshTable();
    }

    private void Table_CellEnter(object sender, DataGridViewCellEventArgs e)
    {
        TableGrid.ClearSelection();
        if (State.BallPicked)
        {
            if (Game.Table[e.RowIndex, e.ColumnIndex] != Ball.None)
            {
                TableGrid.Rows[State.Cell.i].Cells[State.Cell.j].Style.ForeColor = Color.FromName(Game.Table[State.Cell.i, State.Cell.j].ToString());
                TableGrid.Rows[State.Cell.i].Cells[State.Cell.j].Style.BackColor = TableGrid.DefaultCellStyle.BackColor;

                TableGrid.Rows[e.RowIndex].Cells[e.ColumnIndex].Style.ForeColor = TableGrid.DefaultCellStyle.ForeColor;
                TableGrid.Rows[e.RowIndex].Cells[e.ColumnIndex].Style.BackColor = Color.FromName(Game.Table[e.RowIndex, e.ColumnIndex].ToString());

                State.Cell = (e.RowIndex, e.ColumnIndex);
            }
            else
            {
                Game.Move((State.Cell.i, State.Cell.j), (e.RowIndex, e.ColumnIndex));

                State.BallPicked = false;

                Game.EliminateLines((e.RowIndex, e.ColumnIndex));
                if (!Game.CanApplyNextHand())
                {
                    MessageBox.Show("Game Over");
                    Application.Exit();
                }

                Game.ApplyNextHand();
                Game.GenerateNextHand();

                RefreshTable();
                RefreshNextHand();
                RefreshScore();
            }
        }
        else
        {
            if (Game.Table[e.RowIndex, e.ColumnIndex] != Ball.None)
            {
                TableGrid.Rows[e.RowIndex].Cells[e.ColumnIndex].Style.ForeColor = TableGrid.DefaultCellStyle.ForeColor;
                TableGrid.Rows[e.RowIndex].Cells[e.ColumnIndex].Style.BackColor = Color.FromName(Game.Table[e.RowIndex, e.ColumnIndex].ToString());

                State.BallPicked = true;
                State.Cell = (e.RowIndex, e.ColumnIndex);
            }
        }
    }

    private void RefreshTable()
    {
        for (int i = 0; i < Game.Table.Size; i++)
        {
            for (int j = 0; j < Game.Table.Size; j++)
            {
                if (Game.Table[i, j] != Ball.None)
                {
                    TableGrid.Rows[i].Cells[j].Style.ForeColor = Color.FromName(Game.Table[i, j].ToString());
                    TableGrid.Rows[i].Cells[j].Style.BackColor = TableGrid.DefaultCellStyle.BackColor;
                }
                else
                {

                    TableGrid.Rows[i].Cells[j].Style.BackColor = TableGrid.DefaultCellStyle.BackColor;
                    TableGrid.Rows[i].Cells[j].Style.ForeColor = TableGrid.DefaultCellStyle.ForeColor;
                }
            }
        }
    }

    private void NextHand_Click(object sender, EventArgs e)
    {
        if (!Game.CanApplyNextHand())
        {
            MessageBox.Show("Game Over");
            Application.Exit();
        }

        Game.ApplyNextHand();
        Game.GenerateNextHand();

        RefreshTable();
        RefreshNextHand();
        RefreshScore();
    }


    private void RefreshNextHand()
    {

        Ball1.ForeColor = Color.FromName(Game.NextHand[0].ToString());
        Ball2.ForeColor = Color.FromName(Game.NextHand[1].ToString());
        Ball3.ForeColor = Color.FromName(Game.NextHand[2].ToString());
    }

    private void RefreshScore()
    {
        Score.Text = Game.Score.ToString();
    }
}