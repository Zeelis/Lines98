﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lines98Logic;

public class Game
{
    public Table Table { get; }

    public Ball[] NextHand { get; }
    public int Score { get; private set; }

    public Game(int tableSize, int nextHandSize)
    {
        Table = new Table(tableSize);
        NextHand = new Ball[nextHandSize];
    }

    public void Move((int i, int j) from, (int i, int j) to)
    {
        Table[to.i, to.j] = Table[from.i, from.j];
        Table[from.i, from.j] = Ball.None;
    }

    public void EliminateLines((int row, int column) around)
    {
        EliminateHorizontalLine(around);
        EliminateVerticalLine(around);
        EliminateLeftDiagonalLine(around);
        EliminateRightDiagonalLine(around);

        void EliminateHorizontalLine((int row, int column) around)
        {
            Ball initial = Table[around.row, 0];
            int length = 1;

            for (int column = 1; column < Table.Size; column++)
            {
                if (Table[around.row, column] == initial)
                    length++;
                else
                {
                    if (length >= 5)
                    {
                        if(initial != Ball.None)
                        {
                            EliminateLine((around.row, column - length), (around.row, column));
                            Score += length * 2;
                        }
                        return;
                    }

                    else
                    {
                        initial = Table[around.row, column];
                        length = 1;
                    }
                }
            }
            if (length >= 5 && initial != Ball.None)
            {
                EliminateLine((around.row, Table.Size - length), (around.row, Table.Size));
                Score += length * 2;
            }
        }

        void EliminateVerticalLine((int row, int column) around)
        {
            Ball initial = Table[0, around.column];
            int length = 1;

            for (int row = 1; row < Table.Size; row++)
            {
                if (Table[row, around.column] == initial)
                    length++;
                else
                {
                    if (length >= 5)
                    {
                        if (initial != Ball.None)
                        {
                            EliminateLine((row - length, around.column), (row, around.column));
                            Score += length * 2;
                        }
                        return;
                    }

                    else
                    {
                        initial = Table[row, around.column];
                        length = 1;
                    }
                }
            }
            if (length >= 5 && initial != Ball.None)
            {
                EliminateLine((Table.Size - length, around.column), (Table.Size, around.column));
                Score += length * 2;
            }
        }

        void EliminateLeftDiagonalLine((int row, int column) around)
        {
            int row = around.row - Math.Min(around.row, around.column);
            int column = around.column - Math.Min(around.row, around.column);

            Ball initial = Table[row, column];
            int length = 1;

            for ( row++, column++ ; row < Table.Size && column < Table.Size; row++, column++)
            {
                if (Table[row, column] == initial)
                    length++;
                else
                {
                    if (length >= 5)
                    {
                        if(initial != Ball.None)
                        {
                            EliminateLine((row - length, column - length), (row, column));
                            Score += length * 2;
                        }
                        return;
                    }

                    else
                    {
                        initial = Table[row, column];
                        length = 1;
                    }
                }
            }
            if (length >= 5 && initial != Ball.None)
            {
                EliminateLine((row - length, column - length), (row, column));
                Score += length * 2;
            }
        }

        void EliminateRightDiagonalLine((int row, int column) around)
        {
            int row = around.row + Math.Min(Table.Size - around.row - 1, around.column);
            int column = around.column - Math.Min(Table.Size - around.row - 1, around.column);

            Ball initial = Table[row, column];
            int length = 1;

            for (row--, column++; row > -1 && column < Table.Size; row--, column++)
            {
                if (Table[row, column] == initial)
                    length++;
                else
                {
                    if (length >= 5)
                    {
                        if (initial != Ball.None)
                        {
                            EliminateLine((row + length, column - length), (row, column));
                            Score += length * 2;
                        }
                        return;
                    }

                    else
                    {
                        initial = Table[row, column];
                        length = 1;
                    }
                }
            }
            if (length >= 5 && initial != Ball.None)
            {
                EliminateLine((row + length, column - length), (row, column));    
                Score += length * 2;
            }
        }

        void EliminateLine((int row, int column) from, (int row, int column) to)
        {
            if (from.row == to.row)
            {
                for (int column = from.column; column < to.column; column++)
                    Table[from.row, column] = Ball.None;
            }
            else if (from.column == to.column)
            {
                for (int row = from.row; row < to.row; row++)
                    Table[row, from.column] = Ball.None;
            }

            else if (from.row < to.row)
            {
                for (int row = from.row, column = from.column; row < to.row; row++, column++)
                    Table[row, column] = Ball.None;
            }
            else if (from.row > from.column)
            {
                for (int row = from.row, column = from.column; row > to.row; row--, column++)
                    Table[row, column] = Ball.None;
            }
            else { }
        }

    }

    public void GenerateNextHand()
    {
        Ball[] balls = Enum.GetValues<Ball>();

        for (int i = 0; i < NextHand.Length;)
        {
            Random random = new Random();
            Ball randomBall = balls[random.Next(1, balls.Length)];
            if (!NextHand.Contains(randomBall))
                NextHand[i++] = randomBall;
        }
    }
    public bool CanApplyNextHand()
    {
        int emptyCells = 0;
        for (int i = 0; i < Table.Size; i++)
            for (int j = 0; j < Table.Size; j++)
                if (Table[i, j] == Ball.None)
                    emptyCells++;
        return emptyCells > NextHand.Length;
    }
    public void ApplyNextHand()
    {


        for (int i = 0; i < NextHand.Length;)
        {
            Random random = new Random();
            (int i, int j) randomCell = (random.Next(Table.Size), random.Next(Table.Size));
            if (Table[randomCell.i, randomCell.j] == Ball.None)
                Table[randomCell.i, randomCell.j] = NextHand[i++];
        }
    }
}