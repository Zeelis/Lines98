﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lines98Logic;

public enum Ball
{
    None,
    Purple,
    Red,
    Green,
    Blue,
    Orange
}
