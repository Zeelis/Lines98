﻿using System.Drawing;

namespace Lines98Logic;

public class Table
{
    private Ball[,] _layout { get; }

    public int Size { get => _layout.GetLength(0); }

    public Table(int size)
    {
        _layout = new Ball[size, size];
    }
    public Ball this[int i, int j]
    {
        get { return _layout[i, j]; }
        internal set { _layout[i, j] = value; }
    }

}